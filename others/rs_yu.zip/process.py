import os
import random
import re
import time

import bibtexparser

import scholar

querier = scholar.ScholarQuerier()
settings = scholar.ScholarSettings()
querier.apply_settings(settings)


def try_get_num_of_citations(title, year):
    print("Title: " + title)
    query = scholar.SearchScholarQuery()
    query.set_words(title)

    querier.send_query(query)

    if not os.path.exists("cookie"):
        querier.save_cookies()

    if len(querier.articles) < 1:
        print("[Error] No result")
        return 0
    else:
        attrs = querier.articles[0].attrs

        if attrs["year"][0] != year:
            print("[Error] Year not match")
            return 0

        return attrs["num_citations"][0]


for fname in os.listdir("data"):
    with open("data/" + fname) as bib_file:
        year = fname[-8:-4]
        bib_data = bibtexparser.load(bib_file)
        lines = ["title,group,num_citations"]
        for entry in bib_data.entries:
            n_authors = len(entry["author"].split(" and"))

            norm_title = re.sub(r"[^a-zA-Z0-9 ]", " ", entry["title"])
            norm_title = re.sub(r" {2,}", " ", norm_title)
            n_citations = try_get_num_of_citations(norm_title, year)

            lines.append(
                ",".join(
                    [
                        norm_title,
                        str(n_authors if n_authors < 4 else 4),
                        str(n_citations),
                    ]
                )
            )

            with open("tmp/" + fname.replace("bib", "tmp"), "w") as w:
                w.write("\n".join(lines))

            time.sleep(60 + random.randint(0, 30))

    break
